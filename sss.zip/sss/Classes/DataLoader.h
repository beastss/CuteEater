#ifndef __DATA_LOADER_H__
#define __DATA_LOADER_H__

class DataLoader
{
public:
	void loadData();
};
#endif