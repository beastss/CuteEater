#include "EnemySnake.h"
#include "CommonMacro.h"
#include "Snake.h"
#include "CommonUtil.h"
#include "GamePanel.h"
#include "RankingModel.h"
USING_NS_CC;
using namespace std;

EnemySnake::EnemySnake(GamePanel *gamePanel, const SnakeData &data)
: Snake(gamePanel)
{

}

void EnemySnake::onExit()
{
	Snake::onExit();
	RankingModel::theModel()->removeRank(m_data.name);
}

EnemySnake *EnemySnake::create(GamePanel *gamePanel, const SnakeData &data)
{
	EnemySnake *snake = EnemySnake::onCreat(gamePanel, data);
	snake->init();
	//snake->autorelease();
	return snake;
}
void EnemySnake::addHead()
{
	auto path = SnakeSkinRes::SnakeResData()->getHeadRes(m_data.skinId);
	//CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFrame("sprite_frames/gni_idle_00000.png");
	//CCSpriteFrame *he = CCSpriteFrame::create("sprite_frames/gni_idle_00000.png",);
	auto head = CCSprite::create(SnakeSkinRes::SnakeResData()->getHeadRes(m_data.skinId).c_str());//SnakeSkinRes::SnakeResData()->getHeadRes(m_data.skinId).c_str()
	CCAnimation *animation = CCAnimation::create();
	//�ӱ����ļ�ϵͳ�м���ͼƬ�ļ���CCSpriteFrame������Ȼ�����ӵ�CCAnimation��  
	for (int i = 0; i < 4; i++)
	{
		char szImageFileName[128] = { 0 };
		sprintf(szImageFileName, SnakeSkinRes::SnakeResData()->getTailRes(m_data.skinId).c_str(), m_data.skinId,i);
		animation->addSpriteFrameWithFileName(szImageFileName);
	}
	animation->setDelayPerUnit(0.2f); // �����������14֡���������2.8��.  
	animation->setRestoreOriginalFrame(true); // 14֡������֮�󷵻ص���һ֡  

	CCAnimate *action = CCAnimate::create(animation);
	head->runAction(CCRepeatForever::create(action));  // ���о������  
	head->setScale(m_scale);
	m_gamePanel->getSnakeBatch()->addChild(head);

	m_nameLabel = CCLabelTTF::create("", "Arial", 17);
	m_nameLabel->setColor(ccc3(0, 0, 0));
	addChild(m_nameLabel, 1);
	m_body.push_back(head);
}
bool EnemySnake::init()
{
	CCPoint pos;
	pos.x = CommonUtil::getRandomValue(0, GAME_LAYER_WIDTH);
	pos.y = CommonUtil::getRandomValue(0, GAME_LAYER_HEIGHT);
	initBodyPos(pos);

	if (m_data.name.empty())
	{
		m_data.name = RankingModel::theModel()->applyName();
	}
	m_nameLabel->setString(m_data.name.c_str());
	return true;
}
EnemySnake * EnemySnake::onCreat(GamePanel *gamePanel, const SnakeData &data)
{
	EnemySnake* pSnake = new EnemySnake(gamePanel, data);

	if (pSnake && pSnake->initSnake())
	{
		pSnake->autorelease();
	}
	else
	{
		//CC_SAFE_DELETE(pSnake);
	}

	return pSnake;

}

void EnemySnake::onMove(cocos2d::CCPoint pos)
{
	const float detectSize = 50;

	if ((pos.x < detectSize && (90 < m_destAngle && m_destAngle < 270))
		|| (pos.x > GAME_LAYER_WIDTH - detectSize && (90 > m_destAngle || m_destAngle > 270)))
	{
		m_destAngle = 180 - m_destAngle;
	}
	else if (pos.y < detectSize && (m_destAngle > 180)
		|| (pos.y > GAME_LAYER_HEIGHT - detectSize && (m_destAngle < 180)))
	{
		m_destAngle = -m_destAngle;
	}

	m_destAngle = (m_destAngle + 360) % 360;
	detectCollision();
}


void EnemySnake::onDead()
{
	//auto snake = EnemySnake::create(m_gamePanel);
	//m_gamePanel->addSnake(snake);
	//m_gamePanel->removeSnake(this);
	//removeFromParent();
}

void EnemySnake::detectCollision()
{
	/*auto snakes = m_gamePanel->getSnakes();
	for (auto snake : snakes)
	{
		if (snake != this && snake->willCrash(getHead()->getPosition(), m_destAngle))
		{
			m_destAngle += CommonUtil::getRandomValue(90, 270);
			return;
		}
	}*/
}