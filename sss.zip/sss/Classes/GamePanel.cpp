#include "GamePanel.h"
#include "PlayerSnake.h"
#include "CommonMacro.h"
#include "UiLayer.h"
#include "EnemySnake.h"
#include "FoodMgr.h"
#include "Food.h"
#include <algorithm>
#include "PlayerData.h"
#include "MainScene.h"
#include "SoundMgr.h"
#include "RankingModel.h"
#include "StageMgr.h"
#include "GameOverDialog.h"
#include "NextStageDialog.h"
using namespace std;
USING_NS_CC;

GamePanel::GamePanel()
:ispause(false)
{
	m_foodMgr = new FoodMgr(this);
}

GamePanel::~GamePanel()
{
	delete m_foodMgr;
}

bool GamePanel::init()
{
	RankingModel::theModel()->reset();
	PlayerData::theData()->reset();
	auto winSize = CCDirector::sharedDirector()->getWinSize();
	
	//������
	auto bk = CCLayerColor::create(ccc4(120, 0, 0, 200));
	addChild(bk);
	//������
	m_snakeField = CCNode::create();
	initGameBk();
	m_snakeField->setContentSize(CCSize(GAME_LAYER_WIDTH, GAME_LAYER_HEIGHT));
	m_snakeField->setAnchorPoint(ccp(0.5f, 0.5f));
	m_snakeField->setPosition(ccpMult(winSize, 0.5f));
	addChild(m_snakeField);
	m_snakeBatchNode = CCNode::create();
	m_snakeField->addChild(m_snakeBatchNode);
	//ghost
	m_ghostField = CCNode::create();
	m_ghostField->setContentSize(CCSize(GAME_LAYER_WIDTH, GAME_LAYER_HEIGHT));
	m_ghostField->setAnchorPoint(ccp(0.5f, 0.5f));
	m_ghostField->setPosition(ccpMult(winSize, 0.5f));
	addChild(m_ghostField);
	//ui��
	m_uiLayer = UiLayer::create();
	addChild(m_uiLayer);
	initSnakes();
	initGhost();
	setContentSize(winSize);
	scheduleUpdate();
	// ����ʳ��
	m_foodMgr->genNewFood(Stage->foods[Stage->currentstage - 1]);
	m_uiLayer->trsfoodmgr(m_foodMgr);
    return true;
}

void GamePanel::initGameBk()
{
	CCSpriteBatchNode* batchNode = CCSpriteBatchNode::create("game_scene/map_01.png");
	/*
	char str [100]={0};
	sprintf(str,"game_scene/map_0%d.png",Stage->currentstage);
	
	*/
	m_snakeField->addChild(batchNode);
	const float gridSize = 40;
	int xGrids = GAME_LAYER_WIDTH / gridSize;
	int yGrids = GAME_LAYER_HEIGHT / gridSize;
	for (int i = 0; i < yGrids; ++i)
	{
		for (int j = 0; j < xGrids; ++j)
		{
			CCSprite *spr = CCSprite::createWithTexture(batchNode->getTexture());
			spr->setAnchorPoint(ccp(0, 0));
			CCPoint pos;
			pos.x = gridSize * j;
			pos.y = gridSize * i;
			spr->setPosition(pos);
			batchNode->addChild(spr);
		}
	}
	//this->scheduleOnce(schedule_selector(GamePanel::jifei),30.0f);
	//CCSprite * spr = CCSprite::create("game_scene/bg.png");
	//auto size = CCSize(GAME_LAYER_WIDTH,GAME_LAYER_HEIGHT);
	//spr->setPosition(ccpMult(size, 0.5));
	//m_snakeField->addChild(spr);
}

void GamePanel::jifei(float dt)
{
	MainScene::theScene()->showDialog(PackageDialog::create());

}
void GamePanel::update(float dt)
{
	if (!ispause)
	{
		for (size_t i = 0; i < m_snakes.size(); ++i)
		{
			m_snakes[i]->update(dt);
		}
		for (size_t i = 0; i < m_ghosts.size(); i++)
		{
			m_ghosts[i]->update(dt);
		}
		m_foodMgr->update(dt);
		//CCLOG("left time: %d", timeLeft -= dt)
		m_uiLayer->updatetime(Stage->time[Stage->currentstage - 1] -= dt, Stage->currentstage);
		if (Stage->time[Stage->currentstage - 1] <= 0)
		{
			//��Ϸ����
			Stage->reset();
			//auto dialog = RebornDialog::create(m_gamePanel);
			//MainScene::theScene()->showDialog(dialog);
			pausePanel();
			SoundMgr::theMgr()->playEffect(kEffectMusicButton);
			MainScene::theScene()->showDialog(GameOverDialog::create());
		}
		int a = Stage->foods[Stage->currentstage - 1];
		CCLOG("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb%d", a);
		if (Stage->foods[Stage->currentstage - 1] <= 0)
		{
			//��һ��
			Stage->currentstage += 1;
			pausePanel();
			SoundMgr::theMgr()->playEffect(kEffectMusicButton);
			MainScene::theScene()->showDialog(NextStageDialog::create());

		}
	}
	
}

void GamePanel::setFocus(cocos2d::CCPoint pos)
{
	auto winSize = CCDirector::sharedDirector()->getWinSize();
	CCPoint newPos;
	newPos.x = winSize.width * 0.5f - pos.x + GAME_LAYER_WIDTH * 0.5f;
	newPos.y = winSize.height * 0.5f - pos.y + GAME_LAYER_HEIGHT * 0.5f;
	
	m_snakeField->setPosition(newPos);
}

void GamePanel::initSnakes()
{

	SnakeData data;
	data.length = INIT_SNAKE_LENGTH;
	data.skinId = 2;
	//data.length = 100; 
	m_playsnake = PlayerSnake::create(this, data);
	addSnake(m_playsnake);
	//return;
	for (int i = 1; i < SNAKE_NUM; ++i)
	{
		SnakeData data;
		data.length = INIT_SNAKE_LENGTH;
		data.skinId = i;
		addSnake(EnemySnake::create(this, data));
	}
	//addFood(cocos2d::ccColor3B color, cocos2d::CCPoint pos);

}

void GamePanel::initGhost()
{
	for (int i = 1; i < Stage->ghost[Stage->currentstage]; ++i)
	{

		addGhost(Ghost::onCreat(this,m_playsnake));
	}

}

void GamePanel::addSnake(Snake *snake)
{
	m_snakeField->addChild(snake);
	m_snakes.push_back(snake);
	updateTarget();
}

void GamePanel::addGhost(Ghost *ghost)
{
	m_ghostField->addChild(ghost);
	m_ghosts.push_back(ghost);
}

void GamePanel::removeSnake(Snake *snake)
{

	snake->removeFromParent();
	auto iter = find(m_snakes.begin(), m_snakes.end(), snake);
	if (iter != m_snakes.end())
	{
		//ע�⣺����ɾ��snake �᲻�ᵼ���ϲ�ı���������
		m_snakes.erase(iter);
	}
	updateTarget();

}

void GamePanel::updateTarget()
{
	for (auto gho : m_ghosts)
	{
		gho->targetSnake();
	}
}

void GamePanel::addFood(cocos2d::ccColor3B color, cocos2d::CCPoint pos)
{
	if (pos.x <= 10) pos.x = 10;
	if (pos.x >= GAME_LAYER_WIDTH - 10) pos.x = GAME_LAYER_WIDTH - 10;
	if (pos.y <= 10) pos.y = 10;
	if (pos.y >= GAME_LAYER_HEIGHT - 10) pos.y = GAME_LAYER_HEIGHT - 10;
	
	auto food = new Food(color);
	food->getView()->setPosition(pos);
	m_snakeBatchNode->addChild(food->getView(), -10000);
	m_foodMgr->addFood(food);
}

void GamePanel::addFood(std::string path, cocos2d::CCPoint pos)
{
	/*if (pos.x <= 10) pos.x = 10;
	if (pos.x >= GAME_LAYER_WIDTH - 10) pos.x = GAME_LAYER_WIDTH - 10;
	if (pos.y <= 10) pos.y = 10;
	if (pos.y >= GAME_LAYER_HEIGHT - 10) pos.y = GAME_LAYER_HEIGHT - 10;

	auto food = new Food(path);
	food->getView()->setPosition(pos);
	m_snakeBatchNode->addChild(food->getView(), -9999);
	m_foodMgr->addFood(food);*/
}

void GamePanel::onBackKeyTouched()
{
	SoundMgr::theMgr()->playEffect(kEffectMusicButton);
	MainScene::theScene()->showPanel(kPanelIdMenuPanel);
}